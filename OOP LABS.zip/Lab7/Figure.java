package Lab7;

abstract class Figure {
    public abstract double getArea();

    public abstract double getPerimeter();
}
