package com.lab1.task1;

public class Monitor {
     String color;
     float dimension;
     int resolution;
}