package Lab6;

import java.util.Date;

public class Staff extends Person {
    private Date joined;
    private String[] education;
    private String[] certification;
    private String[] languages;

    private Department department;
}
