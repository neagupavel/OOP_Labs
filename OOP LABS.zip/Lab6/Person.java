package Lab6;

import java.util.Date;

public class Person {
    private String title;
    private String givenName;
    private String middleName;
    private String familyName;
    protected FullName name;
    protected Date birthDate;
    protected Gender gender;
    private Address homeAddress;
    private Phone phone;

    private Hospital[] hospitals;
}
