package Lab6;

public class Surgeon extends Doctor {
}