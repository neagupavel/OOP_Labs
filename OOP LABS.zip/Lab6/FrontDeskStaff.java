package Lab6;

public class FrontDeskStaff extends AdministrativeStaff {
}
