package Lab6;

public class OperationsStaff extends Staff {
    private Patient[] patients;
}
