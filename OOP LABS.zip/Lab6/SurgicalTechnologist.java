package Lab6;

public class SurgicalTechnologist extends Technologist {
}
