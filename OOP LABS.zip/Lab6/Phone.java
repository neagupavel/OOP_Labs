package Lab6;

public class Phone {
}
