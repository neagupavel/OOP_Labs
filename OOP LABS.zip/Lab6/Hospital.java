package Lab6;

public class Hospital {
    private String name;
    private Address address;
    private Phone phone;

    private Person[] people;
    private Department[] departments;
}
