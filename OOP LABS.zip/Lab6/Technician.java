package Lab6;

public class Technician extends TechnicalStaff {
}