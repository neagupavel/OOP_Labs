package Lab6;

public class TechnicalStaff extends Staff {
}