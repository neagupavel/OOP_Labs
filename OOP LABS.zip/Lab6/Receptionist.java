package Lab6;

public class Receptionist extends FrontDeskStaff {
}
