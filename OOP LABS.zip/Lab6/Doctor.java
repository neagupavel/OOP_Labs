package Lab6;

public class Doctor extends OperationsStaff {
    private String[] specialty;
    private String[] locations;
}
