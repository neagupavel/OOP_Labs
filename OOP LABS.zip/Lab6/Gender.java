package Lab6;

public enum Gender {
    Male,
    Female
}
