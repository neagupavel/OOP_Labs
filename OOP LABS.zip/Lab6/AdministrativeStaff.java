package Lab6;

public class AdministrativeStaff extends Staff {
}
