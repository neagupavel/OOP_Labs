package Lab6;

public class Nurse extends OperationsStaff {
}
