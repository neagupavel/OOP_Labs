package Lab6;

public class Department {
    private Hospital hospital;

    private Staff[] staffs;
}
