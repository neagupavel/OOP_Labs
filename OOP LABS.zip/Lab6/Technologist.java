package Lab6;

public class Technologist extends TechnicalStaff {
}
