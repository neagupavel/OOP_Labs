package Lab5_task3.task3;

public class X {
    private String name;

    public X(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
