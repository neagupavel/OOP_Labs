package Lab9;

public class UnluckyException extends Exception {
    public UnluckyException(String errorMessage) {
        super(errorMessage);
    }
}


