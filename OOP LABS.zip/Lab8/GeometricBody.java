package Lab8;


public interface GeometricBody {
    public abstract double getSurface();

    public abstract double getVolume();
}
